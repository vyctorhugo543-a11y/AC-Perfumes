/**
 * AC PERFUMES - ALTA PERFUMARIA DE LUXO
 * Application Core & Storefront Logic
 */

const WHATSAPP_PHONE = "5516991907811";
const STORE_NAME = "AC Perfumes";

// Complete 41-Perfume Catalog Database
const perfumes = [
  // --- PERFUMES ÁRABES (18) ---
  {
    id: 1,
    name: "Monarch",
    brand: "Al Wataniah (Rawae'e Monarch)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 400,00",
    priceValue: 400.00,
    category: "arabes",
    gender: "masculino",
    badgeText: "Árabe Nobre",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/monarch.jpg",
    description: "Aromático frutado com toque oriental luxuoso. Abertura refinada com oxicoco (cranberry) e mandarina, corpo de rosa búlgara, magnólia e gerânio, e fundo quente de almíscar e patchouli."
  },
  {
    id: 2,
    name: "Off Nature",
    brand: "Lattafa Pride (Art of Nature I)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 480,00",
    priceValue: 480.00,
    category: "arabes",
    gender: "unissex",
    badgeText: "Árabe Exclusivo",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/off-nature.jpg",
    description: "Criação de alta costura da linha Lattafa Pride. Notas profundas de figo, ameixa e groselha preta sobre uma base suntuosa de couro nobre, oud (agarwood) e baunilha aveludada."
  },
  {
    id: 3,
    name: "Yara Rosa",
    brand: "Lattafa Perfumes",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 340,00",
    priceValue: 340.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Mais Vendido",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/yara-rosa.jpg",
    description: "O perfume árabe feminino mais famoso e cobiçado do mundo. Fragrância gourmand cremosa, com acordes de heliotrópio, tangerina, orquídea, frutas tropicais doces, baunilha e almíscar."
  },
  {
    id: 4,
    name: "Safeek",
    brand: "Lattafa (Al Noble Safeer)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 300,00",
    priceValue: 300.00,
    category: "arabes",
    gender: "masculino",
    badgeText: "Árabe Nobre",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/safeek.webp",
    description: "Frasco icônico verde com tampa em escultura régia. Aroma aromático e especiado fresco com notas de artemísia, bergamota, ervas aromáticas finas, cipreste e madeiras nobres."
  },
  {
    id: 5,
    name: "Durrat",
    brand: "Al Wataniah (Durrat Al Aroos)",
    volume: "Eau de Parfum 85ml",
    priceFormatted: "R$ 340,00",
    priceValue: 340.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/durrat.jpg",
    description: "Conhecido como a 'Pérola da Noiva'. Fragrância oriental refinada com almíscar branco sensual, baunilha suave, âmbar aconchegante e toques de orquídea e fava tonka."
  },
  {
    id: 6,
    name: "Asad Boukbon",
    brand: "Lattafa (Asad Bourbon)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 460,00",
    priceValue: 460.00,
    category: "arabes",
    gender: "masculino",
    badgeText: "Árabe Masculino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/asad-bourbon.jpg",
    description: "Lançamento de alta intensidade da Lattafa. Combinação inebriante de ameixa Mirabelle, lavanda fina, cacau intenso, noz-moscada e rica baunilha Bourbon amadeirada."
  },
  {
    id: 7,
    name: "Sabah",
    brand: "Al Wataniah (Sabah Al Ward)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 240,00",
    priceValue: 240.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/sabah.jpg",
    description: "Sensação árabe misteriosa e sedutora. Notas de pimenta rosa, mandarina, cacau refinado, jasmim sambac, fava tonka e baunilha doce marcante."
  },
  {
    id: 8,
    name: "Yara Tous",
    brand: "Lattafa Perfumes",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 280,00",
    priceValue: 280.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/yara-tous.jpg",
    description: "A versão tropical e ensolarada da linha Yara (frasco amarelo). Explosão cremosa de manga madura, coco suculento, maracujá, jasmim e um fundo aveludado de baunilha e cashmeran."
  },
  {
    id: 9,
    name: "Watani",
    brand: "Al Wataniah",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 240,00",
    priceValue: 240.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/watani.webp",
    description: "Fragrância radiante e festiva. Mistura frutada e doce com notas tropicais ricas, acordes florais vibrantes, âmbar dourado e almíscar sedoso de Dubai."
  },
  {
    id: 10,
    name: "Asad",
    brand: "Lattafa Perfumes",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 340,00",
    priceValue: 340.00,
    category: "arabes",
    gender: "masculino",
    badgeText: "Árabe Mais Vendido",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/asad.jpg",
    description: "O maior clássico masculino da Lattafa. Notas de pimenta preta, tabaco aromático, abacaxi caramelizado, café, íris e âmbar amadeirado. Potente e de altíssima fixação."
  },
  {
    id: 11,
    name: "Club Intense",
    brand: "Armaf (Club de Nuit Intense Man)",
    volume: "Eau de Toilette 105ml",
    priceFormatted: "R$ 440,00",
    priceValue: 440.00,
    category: "arabes",
    gender: "masculino",
    badgeText: "Árabe Masculino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/club-intense.webp",
    description: "Lendário perfume árabe com projeção avassaladora. Abre com limão fresco, abacaxi e groselha preta, evoluindo para bétula esfumaçada, jasmim e patchouli nobre."
  },
  {
    id: 12,
    name: "No 2",
    brand: "Maison Alhambra / Lattafa (No. 2 Men)",
    volume: "Eau de Parfum 80ml",
    priceFormatted: "R$ 320,00",
    priceValue: 320.00,
    category: "arabes",
    gender: "masculino",
    badgeText: "Árabe Masculino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/no-2.webp",
    description: "Fragrância sofisticada inspirada no estilo urbano contemporâneo. Notas frescas de bergamota e lavanda combinadas com cardamomo, gengibre, sândalo e incenso."
  },
  {
    id: 13,
    name: "Olivia",
    brand: "Maison Alhambra",
    volume: "Eau de Parfum 80ml",
    priceFormatted: "R$ 300,00",
    priceValue: 300.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/olivia.webp",
    description: "Fragrância feminina de deusa. Acorde viciante de baunilha salgada, tangerina verde, flor de gengibre, jasmim aquático, âmbar cinzento e sândalo cremoso."
  },
  {
    id: 14,
    name: "Sabah Sugar",
    brand: "Al Wataniah (Sabah Al Ward Sugar)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 240,00",
    priceValue: 240.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/sabah-sugar.webp",
    description: "A doçura irresistível da linha Sabah. Explosão de frutas vermelhas silvestres com calda de açúcar, morango, cereja, jasmim delicado e baunilha aveludada."
  },
  {
    id: 15,
    name: "Jouri",
    brand: "Lattafa Perfumes",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 480,00",
    priceValue: 480.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/jouri.webp",
    description: "Floral frutal refinado com notas exóticas de pitaya (dragon fruit), cereja, laranja doce, peônia, flor de lótus, fava tonka e baunilha quente."
  },
  {
    id: 16,
    name: "Fakhar Boud",
    brand: "Lattafa (Fakhar Gold Extrait)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 360,00",
    priceValue: 360.00,
    category: "arabes",
    gender: "unissex",
    badgeText: "Árabe Nobre",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/fakhar-boud.webp",
    description: "Edição de luxo dourada da linha Fakhar. Acordes de toranja, pimenta rosa, tuberosa elegante, notas solares, couro aveludado e cashmeran opulento."
  },
  {
    id: 17,
    name: "Wazzer",
    brand: "Lattafa (Al Noble Wazeer)",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 360,00",
    priceValue: 360.00,
    category: "arabes",
    gender: "masculino",
    badgeText: "Árabe Masculino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/wazzer.webp",
    description: "Apresentação régia com detalhes nobres. Toques licorosos e amadeirados de conhaque, uísque, açafrão nobre, sândalo, cedro, mirra e baunilha."
  },
  {
    id: 18,
    name: "Victoria Lattafa",
    brand: "Lattafa Perfumes",
    volume: "Eau de Parfum 100ml",
    priceFormatted: "R$ 273,00",
    priceValue: 273.00,
    category: "arabes",
    gender: "feminino",
    badgeText: "Árabe Feminino",
    badgeClass: "badge-arabe",
    image: "public/images/perfumes/victoria-lattafa.webp",
    description: "Lançamento doce e refinado com a deliciosa nota de torta de limão com merengue, néroli fresco e um rastro aconchegante de baunilha pura."
  },

  // --- PERFUMES IMPORTADOS (23) ---
  {
    id: 19,
    name: "212 VIP Rosé",
    brand: "Carolina Herrera",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 1.054,00",
    priceValue: 1054.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Luxo",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/212-vip-rose.jpg",
    description: "O clássico do glamour nova-iorquino. Acorde espumante de champagne rosé com pimenta rosa, flor de pêssego e fundo amadeirado sofisticado de Queen Wood e almíscar branco."
  },
  {
    id: 20,
    name: "212 VIP Rosé Elixir",
    brand: "Carolina Herrera",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 811,00",
    priceValue: 811.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Luxo",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/212-vip-rose-elixir.jpg",
    description: "Versão ultra intensa e sensual do VIP Rosé com glitter. Groselha preta, flor de cerejeira, tangerina suculenta, patchouli e baunilha de Madagascar."
  },
  {
    id: 21,
    name: "Million Gold",
    brand: "Rabanne (Million Gold For Her)",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 1.165,00",
    priceValue: 1165.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Luxo",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/million-gold.png",
    description: "O grande lançamento de luxo da Rabanne com elo dourado XL. Fragrância floral metálica inovadora com flores brancas voluptuosas, lavanda feminina e almíscar mineral."
  },
  {
    id: 22,
    name: "Lady Million",
    brand: "Rabanne",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 912,00",
    priceValue: 912.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Luxo",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/lady-million.jpg",
    description: "O cobiçado diamante dourado. Floral amadeirado fresco com néroli, framboesa, laranja amarga, jasmim sambac, flor de laranjeira, mel doce e patchouli."
  },
  {
    id: 23,
    name: "Bottled Tonic",
    brand: "Hugo Boss (BOSS Bottled)",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 679,00",
    priceValue: 679.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Masculino",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/bottled-tonic.webp",
    description: "Frescor revigorante para o homem contemporâneo. Notas vibrantes de maçã fresca, toranja, laranja amarga, gengibre picante, canela e vetiver sofisticado."
  },
  {
    id: 24,
    name: "Bottled Infinite",
    brand: "Hugo Boss (BOSS Bottled)",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 588,00",
    priceValue: 588.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Masculino",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/bottled-infinite.webp",
    description: "Fragrância profunda e energizante com maçã, mandarina, canela, lavanda da Provença, alecrim e madeiras nobres de sândalo e oliveira."
  },
  {
    id: 25,
    name: "Hugo Boss Bottled Night",
    brand: "Hugo Boss",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 486,00",
    priceValue: 486.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Masculino",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/hugo-boss-bottled-night.webp",
    description: "Desenvolvido para conquistar a noite. Aroma magnético com lavanda, bétula, violeta africana, louro amarelo e madeira nobre de Louro Amarelo com almíscar."
  },
  {
    id: 26,
    name: "Alive Intense",
    brand: "Hugo Boss (BOSS Alive)",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 770,00",
    priceValue: 770.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Feminino",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/alive-intense.jpg",
    description: "Fragrância ousada que celebra a paixão pela vida. Abertura marcante de framboesa suculenta, corpo de vetiver amadeirado e fundo quente de benjoim dourado."
  },
  {
    id: 27,
    name: "Hugo Boss In Motion",
    brand: "Hugo Boss",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 334,00",
    priceValue: 334.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Masculino",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/hugo-boss-in-motion.webp",
    description: "A clássica esfera prateada de Hugo Boss. Oriental fougère dinâmico com bergamota, folhas de violeta, manjericão, pimenta rosa, canela, cardamomo e sândalo."
  },
  {
    id: 28,
    name: "Azzaro Wanted Eau de Toilette",
    brand: "Azzaro",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 486,00",
    priceValue: 486.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Masculino",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-wanted-edt.jpg",
    description: "Frasco emblemático em formato de tambor de revólver. Amadeirado cítrico com limão da Calábria, gengibre fresco, cardamomo da Guatemala, zimbro e fava tonka."
  },
  {
    id: 29,
    name: "Azzaro Wanted Eau de Parfum",
    brand: "Azzaro",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 512,00",
    priceValue: 512.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Masculino",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-wanted-edp.jpg",
    description: "A versão mais encorpada e sensual de Wanted. Acordes intensos de bagas de zimbro, sálvia aromática e vetiver terroso de alta densidade."
  },
  {
    id: 30,
    name: "Ange ou Démon Givenchy",
    brand: "Givenchy",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 811,00",
    priceValue: 811.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Luxo",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/ange-ou-demon.jpg",
    description: "Frasco em formato de gota de cristal facetada. Oriental floral fascinante que transita entre a luz e a sombra: tomilho branco, mandarina, lírio nobre, orquídea, fava tonka e baunilha."
  },
  {
    id: 31,
    name: "Invictus Victory Elixir",
    brand: "Rabanne",
    volume: "Parfum Intense",
    priceFormatted: "R$ 760,00",
    priceValue: 760.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Luxo",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/invictus-victory-elixir.jpg",
    description: "O ápice da intensidade Invictus. Troféu laqueado com notas de lavandim fresco, cardamomo verde, incenso misterioso, patchouli da Indonésia e fava tonka licorosa."
  },
  {
    id: 32,
    name: "Phantom",
    brand: "Rabanne",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 1.115,00",
    priceValue: 1115.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Luxo",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/phantom.jpg",
    description: "O futurista frasco robô cromado da Rabanne. Fragrância energizante e aromática com lavanda cremosa, raspas de limão energizantes, maçã, fumaça terrosa e baunilha sensual."
  },
  {
    id: 33,
    name: "1 Million",
    brand: "Rabanne",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 608,00",
    priceValue: 608.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Ícone",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/1-million.jpg",
    description: "A lendária barra de ouro de Rabanne. Pomelo radiante, hortelã fresca, mandarina sangínea, rosa absoluta, canela picante, couro aveludado e âmbar keta."
  },
  {
    id: 34,
    name: "Azzaro By Night",
    brand: "Azzaro (Wanted by Night)",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 740,00",
    priceValue: 740.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Noturno",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-by-night.webp",
    description: "O elixir noturno da sedução. Canela quente, tangerina amarela, cedro vermelho, incenso, tabaco aromático e cipreste. Feito para noites memoráveis."
  },
  {
    id: 35,
    name: "Azzaro The Most Parfum",
    brand: "Azzaro (The Most Wanted Parfum)",
    volume: "Parfum",
    priceFormatted: "R$ 730,00",
    priceValue: 730.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Intenso",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-the-most-parfum.webp",
    description: "Frasco todo preto fosco de puro requinte. Gengibre vermelho flamejante, acordes amadeirados intensos e baunilha Bourbon de Madagascar ultra encorpada."
  },
  {
    id: 36,
    name: "Azzaro Pour",
    brand: "Azzaro (Pour Homme)",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 350,00",
    priceValue: 350.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Clássico",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-pour.jpg",
    description: "O maior ícone da perfumaria masculina tradicional francesa. Acorde atemporal com anis estrelado, lavanda, manjericão, vetiver, sândalo, patchouli, musgo de carvalho e couro."
  },
  {
    id: 37,
    name: "Azzaro Chrome 100 ml",
    brand: "Azzaro (Chrome)",
    volume: "Eau de Toilette 100ml",
    priceFormatted: "R$ 446,00",
    priceValue: 446.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Frescor",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-chrome-100ml.jpg",
    description: "Sensação do frescor mediterrâneo em 100ml. Limão refrescante, bergamota, alecrim, néroli, abacaxi, ciclâmen, coentro, musgo de carvalho e cedro nobre."
  },
  {
    id: 38,
    name: "Azzaro Chrome 200 ml",
    brand: "Azzaro (Chrome)",
    volume: "Eau de Toilette 200ml",
    priceFormatted: "R$ 567,00",
    priceValue: 567.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado 200ml",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-chrome-200ml.png",
    description: "A clássica assinatura fresca de Azzaro Chrome na imponente volumetria de 200ml. Perfeito para uso diário prolongado com elegância e vigor."
  },
  {
    id: 39,
    name: "Eternity Moment",
    brand: "Calvin Klein",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 354,00",
    priceValue: 354.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Feminino",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/eternity-moment.webp",
    description: "Fragrância romântica e luminosa. Framboesa, lichia, melão, flor de romã, peônia rosa da China, jasmim, nenúfar aquático e sândalo delicado."
  },
  {
    id: 40,
    name: "Azzaro Pour Elle",
    brand: "Azzaro",
    volume: "Eau de Parfum",
    priceFormatted: "R$ 395,00",
    priceValue: 395.00,
    category: "femininos",
    gender: "feminino",
    badgeText: "Importado Feminino",
    badgeClass: "badge-feminino",
    image: "public/images/perfumes/azzaro-pour-elle.jpg",
    description: "O reflexo feminino da sedução Azzaro. Cardamomo picante, champanhe efervescente, rosa de maio sedutora, lírio e madeira de caxemira envolvente."
  },
  {
    id: 41,
    name: "Azzaro Chrome Azure",
    brand: "Azzaro",
    volume: "Eau de Toilette",
    priceFormatted: "R$ 415,00",
    priceValue: 415.00,
    category: "masculinos",
    gender: "masculino",
    badgeText: "Importado Frescor",
    badgeClass: "badge-masculino",
    image: "public/images/perfumes/azzaro-chrome-azure.webp",
    description: "Lançamento de frescor aquático. O degradê azul do Mediterrâneo traduzido em bergamota italiana cintilante, lavanda francesa e brisa marinha refrescante."
  }
];

// App State
let currentCategory = 'all';
let searchQuery = '';
let sortMode = 'featured';
let cart = [];

// Load Cart from localStorage
try {
  const savedCart = localStorage.getItem('ac_perfumes_cart');
  if (savedCart) {
    cart = JSON.parse(savedCart);
  }
} catch (e) {
  cart = [];
}

function saveCart() {
  try {
    localStorage.setItem('ac_perfumes_cart', JSON.stringify(cart));
  } catch (e) {}
  updateCartBadges();
  renderCart();
}

// Elements
const grid = document.getElementById('product-grid');
const countDisplay = document.getElementById('product-count');
const searchInput = document.getElementById('search-input');
const searchClear = document.getElementById('search-clear');
const filterChips = document.querySelectorAll('.filter-chip');
const sortSelect = document.getElementById('sort-select');
const emptyState = document.getElementById('empty-state');
const resetFiltersBtn = document.getElementById('reset-filters-btn');

// Cart Elements
const cartOverlay = document.getElementById('cart-overlay');
const cartDrawer = document.getElementById('cart-drawer');
const cartCloseBtn = document.getElementById('cart-close-btn');
const cartToggleBtns = document.querySelectorAll('.cart-toggle-trigger');
const cartBadges = document.querySelectorAll('.cart-badge-count');
const cartItemsContainer = document.getElementById('cart-items-container');
const cartEmptyMsg = document.getElementById('cart-empty-msg');
const cartTotalPrice = document.getElementById('cart-total-price');
const cartCheckoutBtn = document.getElementById('cart-checkout-btn');

// Modal Elements
const modalOverlay = document.getElementById('modal-overlay');
const modalClose = document.getElementById('modal-close');
const modalImg = document.getElementById('modal-img');
const modalBadge = document.getElementById('modal-badge');
const modalTitle = document.getElementById('modal-title');
const modalBrand = document.getElementById('modal-brand');
const modalDesc = document.getElementById('modal-desc');
const modalPrice = document.getElementById('modal-price');
const modalInstallment = document.getElementById('modal-installment');
const modalWhatsAppBtn = document.getElementById('modal-whatsapp-btn');
const modalAddBagBtn = document.getElementById('modal-add-bag-btn');

// Helper: Format BRL
function formatBRL(num) {
  return num.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Helper: WhatsApp Single Direct Link
function createWhatsAppDirectLink(name, price) {
  const msg = `Olá, AC Perfumes! Tenho interesse no perfume ${name}, no valor de ${price}. Gostaria de confirmar a disponibilidade e o frete.`;
  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(msg)}`;
}

// Toast Notification
function showToast(message) {
  let toast = document.getElementById('toast-notice');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast-notice';
    toast.className = 'toast-notice';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<span>✨</span> <span>${message}</span>`;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.classList.remove('show');
  }, 2800);
}

// Update Cart Badge Numbers
function updateCartBadges() {
  const totalCount = cart.reduce((acc, item) => acc + item.qty, 0);
  cartBadges.forEach(badge => {
    badge.textContent = totalCount;
    badge.classList.remove('pulse');
    void badge.offsetWidth; // trigger reflow
    badge.classList.add('pulse');
  });
}

// Render Products
function renderProducts() {
  const q = searchQuery.toLowerCase().trim();

  let filtered = perfumes.filter(p => {
    let matchesCategory = true;
    if (currentCategory === 'arabes') {
      matchesCategory = (p.category === 'arabes');
    } else if (currentCategory === 'femininos') {
      matchesCategory = (p.gender === 'feminino' || p.category === 'femininos' || p.gender === 'unissex');
    } else if (currentCategory === 'masculinos') {
      matchesCategory = (p.gender === 'masculino' || p.category === 'masculinos' || p.gender === 'unissex');
    }

    const matchesSearch = !q || 
      p.name.toLowerCase().includes(q) || 
      p.brand.toLowerCase().includes(q) || 
      p.description.toLowerCase().includes(q);

    return matchesCategory && matchesSearch;
  });

  // Sort
  if (sortMode === 'price-asc') {
    filtered.sort((a, b) => a.priceValue - b.priceValue);
  } else if (sortMode === 'price-desc') {
    filtered.sort((a, b) => b.priceValue - a.priceValue);
  } else if (sortMode === 'name-asc') {
    filtered.sort((a, b) => a.name.localeCompare(b.name));
  }

  countDisplay.textContent = `Exibindo ${filtered.length} perfume${filtered.length === 1 ? '' : 's'}`;

  if (filtered.length === 0) {
    grid.innerHTML = '';
    emptyState.style.display = 'block';
    return;
  }

  emptyState.style.display = 'none';

  grid.innerHTML = filtered.map(p => {
    const waLink = createWhatsAppDirectLink(p.name, p.priceFormatted);
    const installmentVal = (p.priceValue / 10).toFixed(2).replace('.', ',');
    return `
      <article class="product-card" data-id="${p.id}">
        <div class="card-photo-wrapper" onclick="openModal(${p.id})">
          <span class="card-badge ${p.badgeClass}">${p.badgeText}</span>
          <img class="card-photo" 
               src="${p.image}" 
               alt="Frasco e embalagem de ${p.name}" 
               loading="lazy"
               onerror="if(!this.dataset.fallback){this.dataset.fallback='1';this.src='${p.image.replace('public/','')}';}">
          <button class="card-details-btn" title="Ver detalhes do perfume" onclick="event.stopPropagation(); openModal(${p.id});">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
              <circle cx="12" cy="12" r="3"></circle>
            </svg>
          </button>
        </div>
        <div class="card-content">
          <div>
            <span class="card-meta">${p.brand}</span>
            <h4 class="card-title" onclick="openModal(${p.id})">${p.name}</h4>
          </div>
          <div>
            <div class="card-price-row">
              <span class="card-price-label">Valor</span>
              <p class="card-price">${p.priceFormatted}</p>
              <span class="card-installment">ou 10x de R$ ${installmentVal}</span>
            </div>
            <div class="card-actions-row">
              <a class="btn-card-whatsapp" href="${waLink}" target="_blank" rel="noopener">
                <svg viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.664-.698c.969.584 1.802.946 2.796.946 3.181 0 5.767-2.586 5.768-5.766.001-3.18-2.585-5.767-5.768-5.767zm7.576 5.767c-.002 4.183-3.402 7.581-7.585 7.581-1.332 0-2.435-.386-3.493-.974l-4.529 1.188 1.21-4.417c-.664-1.121-1.077-2.298-1.076-3.378.002-4.183 3.402-7.581 7.585-7.581 4.183 0 7.588 3.398 7.588 7.581z"/></svg>
                <span>COMPRAR AGORA</span>
              </a>
              <button class="btn-card-add-cart" onclick="addToCart(${p.id})">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0"/></svg>
                <span>Adicionar à Sacola</span>
              </button>
            </div>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

// Shopping Bag (Cart) Operations
function addToCart(id, qty = 1) {
  const perfume = perfumes.find(p => p.id === id);
  if (!perfume) return;

  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id, qty });
  }

  saveCart();
  showToast(`"${perfume.name}" adicionado à sacola!`);
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  saveCart();
}

function changeCartQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (!item) return;

  item.qty += delta;
  if (item.qty <= 0) {
    removeFromCart(id);
  } else {
    saveCart();
  }
}

function renderCart() {
  if (cart.length === 0) {
    cartItemsContainer.innerHTML = '';
    cartEmptyMsg.style.display = 'block';
    cartTotalPrice.textContent = 'R$ 0,00';
    cartCheckoutBtn.disabled = true;
    cartCheckoutBtn.style.opacity = '0.5';
    cartCheckoutBtn.style.pointerEvents = 'none';
    return;
  }

  cartEmptyMsg.style.display = 'none';
  cartCheckoutBtn.disabled = false;
  cartCheckoutBtn.style.opacity = '1';
  cartCheckoutBtn.style.pointerEvents = 'auto';

  let total = 0;
  cartItemsContainer.innerHTML = cart.map(item => {
    const p = perfumes.find(prod => prod.id === item.id);
    if (!p) return '';
    const itemTotal = p.priceValue * item.qty;
    total += itemTotal;

    return `
      <div class="cart-item">
        <img class="cart-item-img" src="${p.image}" alt="${p.name}">
        <div class="cart-item-details">
          <h5 class="cart-item-title">${p.name}</h5>
          <div class="cart-item-price">${formatBRL(p.priceValue)}</div>
          <div class="cart-item-qty-row">
            <button class="qty-btn" onclick="changeCartQty(${p.id}, -1)">-</button>
            <span class="qty-val">${item.qty}</span>
            <button class="qty-btn" onclick="changeCartQty(${p.id}, 1)">+</button>
          </div>
        </div>
        <button class="cart-item-remove" onclick="removeFromCart(${p.id})" title="Remover item">✕</button>
      </div>
    `;
  }).join('');

  cartTotalPrice.textContent = formatBRL(total);

  // Update checkout WhatsApp URL with multiple items
  const lines = cart.map(item => {
    const p = perfumes.find(prod => prod.id === item.id);
    return `• ${item.qty}x ${p.name} (${p.volume}) - ${formatBRL(p.priceValue * item.qty)}`;
  });

  const message = `✨ *NOVO PEDIDO - AC PERFUMES* ✨\n\n` +
    `Olá! Gostaria de consultar a disponibilidade e fechar o pedido dos seguintes perfumes:\n\n` +
    lines.join('\n') +
    `\n\n💳 *Valor Total:* ${formatBRL(total)}\n` +
    `Podemos combinar a forma de envio e pagamento?`;

  cartCheckoutBtn.href = `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(message)}`;
}

function openCartDrawer() {
  cartOverlay.classList.add('active');
  cartDrawer.classList.add('active');
  document.body.style.overflow = 'hidden';
  renderCart();
}

function closeCartDrawer() {
  cartOverlay.classList.remove('active');
  cartDrawer.classList.remove('active');
  document.body.style.overflow = '';
}

cartToggleBtns.forEach(btn => btn.addEventListener('click', openCartDrawer));
cartCloseBtn.addEventListener('click', closeCartDrawer);
cartOverlay.addEventListener('click', closeCartDrawer);

// Quick View Modal
let activeModalPerfumeId = null;

function openModal(id) {
  const p = perfumes.find(item => item.id === id);
  if (!p) return;

  activeModalPerfumeId = id;
  modalImg.src = p.image;
  modalImg.alt = `${p.name} - Frasco e Embalagem Oficial`;
  modalBadge.textContent = p.badgeText;
  modalBadge.className = `modal-badge ${p.badgeClass}`;
  modalTitle.textContent = p.name;
  modalBrand.textContent = `${p.brand} • ${p.volume}`;
  modalDesc.textContent = p.description;
  modalPrice.textContent = p.priceFormatted;

  const installment = (p.priceValue / 10).toFixed(2).replace('.', ',');
  modalInstallment.textContent = `ou em até 10x de R$ ${installment} no cartão`;

  modalWhatsAppBtn.href = createWhatsAppDirectLink(p.name, p.priceFormatted);

  modalOverlay.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modalOverlay.classList.remove('active');
  document.body.style.overflow = '';
}

modalClose.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) closeModal();
});

modalAddBagBtn.addEventListener('click', () => {
  if (activeModalPerfumeId) {
    addToCart(activeModalPerfumeId);
    closeModal();
    openCartDrawer();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (modalOverlay.classList.contains('active')) closeModal();
    if (cartDrawer.classList.contains('active')) closeCartDrawer();
  }
});

// Navigation Helpers
function scrollToCatalog() {
  document.getElementById('catalogo').scrollIntoView({ behavior: 'smooth' });
}

function focusSearch() {
  scrollToCatalog();
  setTimeout(() => {
    searchInput.focus();
  }, 350);
}

function setCategory(cat) {
  currentCategory = cat;
  filterChips.forEach(chip => {
    chip.classList.toggle('active', chip.dataset.filter === cat);
  });
  renderProducts();
  scrollToCatalog();
}

// Filter Chips Listeners
filterChips.forEach(chip => {
  chip.addEventListener('click', () => {
    filterChips.forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    currentCategory = chip.dataset.filter;
    renderProducts();
  });
});

// Sort Selector Listener
sortSelect.addEventListener('change', (e) => {
  sortMode = e.target.value;
  renderProducts();
});

// Search Input Listeners
searchInput.addEventListener('input', (e) => {
  searchQuery = e.target.value;
  searchClear.style.display = searchQuery ? 'block' : 'none';
  renderProducts();
});

searchClear.addEventListener('click', () => {
  searchInput.value = '';
  searchQuery = '';
  searchClear.style.display = 'none';
  searchInput.focus();
  renderProducts();
});

resetFiltersBtn.addEventListener('click', () => {
  searchInput.value = '';
  searchQuery = '';
  searchClear.style.display = 'none';
  setCategory('all');
});

// FAQ Accordion
document.querySelectorAll('.faq-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.parentElement;
    item.classList.toggle('active');
  });
});

// Initialize
updateCartBadges();
renderProducts();
renderCart();
